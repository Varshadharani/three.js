const XLSX = require( 'xlsx');
const fs = require('fs');

// Read the Excel file
const workbook =
XLSX.readFile('data.xlsx');

// Get the first sheet
const sheet =
workbook.Sheets[workbook.SheetNames [0]];

// Convert the sheet to JSON format
const jsonData =
XLSX.utils.sheet_to_json (sheet);

// Save the JSON data to a file
fs.writeFileSync('data.json',
JSON.stringify(jsonData, null, 2));

console.log ('Data has been written to data.json');